/**
 * @file recipe_search.c
 * @author 成员D姓名
 * @brief 查找功能实现
 */

#include "recipe_system.h"
#include <string.h>

// 名称匹配函数（支持简单通配符*）
static int name_matches(const char *pattern, const char *str) {
    if (!pattern || !str) return 0;
    
    // 如果pattern为空或者为*，匹配所有
    if (pattern[0] == '\0' || strcmp(pattern, "*") == 0) {
        return 1;
    }
    
    // 检查是否包含通配符*
    char *star = strchr(pattern, '*');
    if (!star) {
        // 没有通配符，精确匹配
        return strstr(str, pattern) != NULL;  // 改为包含匹配更友好
    }
    
    // 处理通配符（简单实现）
    if (star == pattern) {
        // 以*开头
        return strstr(str, pattern + 1) != NULL;
    } else if (star[1] == '\0') {
        // 以*结尾
        int len = star - pattern;
        return strncmp(str, pattern, len) == 0;
    }
    
    return 0;
}

// 按名称查找
List* manager_search_by_name(RecipeManager *manager, const char *name) {
    if (!manager || !name) return NULL;
    
    // 创建结果链表（注意：只复制指针，不复制数据）
    List *results = list_create(NULL, recipe_compare, recipe_print);
    if (!results) return NULL;
    
    int count = manager_get_count(manager);
    for (int i = 0; i < count; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        if (name_matches(name, recipe->name)) {
            list_append(results, recipe);
        }
    }
    
    printf("找到 %d 个匹配'%s'的菜品\n", results->size, name);
    return results;
}

// 按分类查找
List* manager_search_by_category(RecipeManager *manager, const char *category) {
    if (!manager || !category) return NULL;
    
    List *results = list_create(NULL, recipe_compare, recipe_print);
    if (!results) return NULL;
    
    int count = manager_get_count(manager);
    for (int i = 0; i < count; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        if (strcmp(recipe->category, category) == 0) {
            list_append(results, recipe);
        }
    }
    
    printf("在分类'%s'中找到 %d 个菜品\n", category, results->size);
    return results;
}

// 按配料查找
List* manager_search_by_ingredient(RecipeManager *manager, const char *ingredient) {
    if (!manager || !ingredient) return NULL;
    
    List *results = list_create(NULL, recipe_compare, recipe_print);
    if (!results) return NULL;
    
    int count = manager_get_count(manager);
    for (int i = 0; i < count; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        if (recipe_has_ingredient(recipe, ingredient)) {
            list_append(results, recipe);
        }
    }
    
    printf("找到 %d 个包含'%s'的菜品\n", results->size, ingredient);
    return results;
}

// 按时间范围查找
List* manager_search_by_time(RecipeManager *manager, int min_time, int max_time) {
    if (!manager || min_time < 0 || max_time < 0 || min_time > max_time) {
        return NULL;
    }
    
    List *results = list_create(NULL, recipe_compare, recipe_print);
    if (!results) return NULL;
    
    int count = manager_get_count(manager);
    for (int i = 0; i < count; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        if (recipe->estimated_time >= min_time && recipe->estimated_time <= max_time) {
            list_append(results, recipe);
        }
    }
    
    printf("找到 %d 个预计时间在%d-%d分钟之间的菜品\n", 
           results->size, min_time, max_time);
    return results;
}

// 按难度查找
List* manager_search_by_difficulty(RecipeManager *manager, int difficulty) {
    if (!manager || difficulty < 1 || difficulty > 5) return NULL;
    
    List *results = list_create(NULL, recipe_compare, recipe_print);
    if (!results) return NULL;
    
    int count = manager_get_count(manager);
    for (int i = 0; i < count; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        if (recipe->difficulty == difficulty) {
            list_append(results, recipe);
        }
    }
    
    printf("找到 %d 个难度为%d的菜品\n", results->size, difficulty);
    return results;
}

// 高级查找（组合条件）
List* manager_search_advanced(RecipeManager *manager, const char *conditions) {
    if (!manager || !conditions || conditions[0] == '\0') {
        return manager_search_by_name(manager, "*");  // 返回所有
    }
    
    // 解析条件字符串（简单实现）
    // 格式：名称=鱼香,分类=川菜,难度=3,时间<30
    char name_pattern[100] = "*";
    char category[100] = "*";
    int min_time = 0, max_time = 9999;
    int difficulty = -1;
    
    char *copy = strdup(conditions);
    char *token = strtok(copy, ",");
    
    while (token) {
        char *eq = strchr(token, '=');
        if (eq) {
            *eq = '\0';
            char *key = token;
            char *value = eq + 1;
            
            // 去除空格
            while (*key == ' ') key++;
            while (key[strlen(key)-1] == ' ') key[strlen(key)-1] = '\0';
            while (*value == ' ') value++;
            while (value[strlen(value)-1] == ' ') value[strlen(value)-1] = '\0';
            
            if (strcmp(key, "名称") == 0 || strcmp(key, "name") == 0) {
                strncpy(name_pattern, value, sizeof(name_pattern)-1);
            } else if (strcmp(key, "分类") == 0 || strcmp(key, "category") == 0) {
                strncpy(category, value, sizeof(category)-1);
            } else if (strcmp(key, "难度") == 0 || strcmp(key, "difficulty") == 0) {
                difficulty = atoi(value);
            } else if (strcmp(key, "时间") == 0 || strcmp(key, "time") == 0) {
                char *lt = strchr(value, '<');
                char *gt = strchr(value, '>');
                if (lt) {
                    max_time = atoi(lt + 1);
                } else if (gt) {
                    min_time = atoi(gt + 1);
                } else {
                    // 精确时间
                    int exact = atoi(value);
                    min_time = exact - 5;
                    max_time = exact + 5;
                }
            }
        }
        token = strtok(NULL, ",");
    }
    
    free(copy);
    
    // 执行查找
    List *results = list_create(NULL, recipe_compare, recipe_print);
    if (!results) return NULL;
    
    int count = manager_get_count(manager);
    for (int i = 0; i < count; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        
        // 检查所有条件
        int match = 1;
        
        // 名称匹配
        if (!name_matches(name_pattern, recipe->name)) {
            match = 0;
        }
        
        // 分类匹配
        if (strcmp(category, "*") != 0 && strcmp(recipe->category, category) != 0) {
            match = 0;
        }
        
        // 难度匹配
        if (difficulty != -1 && recipe->difficulty != difficulty) {
            match = 0;
        }
        
        // 时间匹配
        if (recipe->estimated_time < min_time || recipe->estimated_time > max_time) {
            match = 0;
        }
        
        if (match) {
            list_append(results, recipe);
        }
    }
    
    printf("高级查找找到 %d 个菜品\n", results->size);
    return results;
}
