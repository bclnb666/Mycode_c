/**
 * @file recipe.h
 * @author 成员A姓名
 * @brief 菜品数据结构定义
 * @date 2024-01-15
 */

#ifndef RECIPE_H
#define RECIPE_H

#include "linked_list.h"

#define MAX_NAME_LEN 50
#define MAX_CATEGORY_LEN 30
#define MAX_INGREDIENT_LEN 50
#define MAX_INGREDIENTS 20

// 菜品结构
typedef struct Recipe {
    int id;                     // 菜品ID（唯一）
    char name[MAX_NAME_LEN];    // 菜品名称
    char category[MAX_CATEGORY_LEN]; // 分类
    int estimated_time;         // 预计时间（分钟）
    int difficulty;             // 难度等级（1-5）
    List *ingredients;          // 配料链表（使用通用链表）
} Recipe;

// ==================== 菜品API ====================

/**
 * @brief 创建新菜品
 * 
 * @param id 菜品ID
 * @param name 菜品名称
 * @param category 菜品分类
 * @return Recipe* 成功返回菜品指针，失败返回NULL
 */
Recipe* recipe_create(int id, const char *name, const char *category);

/**
 * @brief 销毁菜品，释放内存
 * 
 * @param recipe 菜品指针
 */
void recipe_destroy(void *recipe);

/**
 * @brief 菜品比较函数（供链表库调用）
 * 
 * @param a 菜品A
 * @param b 菜品B
 * @return int a>b返回正数，a<b返回负数，相等返回0
 */
int recipe_compare(void *a, void *b);

/**
 * @brief 菜品打印函数（供链表库调用）
 * 
 * @param recipe 菜品指针
 */
void recipe_print(void *recipe);

/**
 * @brief 添加配料到菜品
 * 
 * @param recipe 菜品指针
 * @param ingredient 配料名称
 * @return int 成功返回0，失败返回-1
 */
int recipe_add_ingredient(Recipe *recipe, const char *ingredient);

/**
 * @brief 设置菜品预计时间
 * 
 * @param recipe 菜品指针
 * @param minutes 分钟数
 */
void recipe_set_estimated_time(Recipe *recipe, int minutes);

/**
 * @brief 设置菜品难度
 * 
 * @param recipe 菜品指针
 * @param level 难度等级（1-5）
 * @return int 成功返回0，失败返回-1
 */
int recipe_set_difficulty(Recipe *recipe, int level);

/**
 * @brief 显示菜品详细信息
 * 
 * @param recipe 菜品指针
 */
void recipe_display(Recipe *recipe);

/**
 * @brief 检查菜品是否包含某配料
 * 
 * @param recipe 菜品指针
 * @param ingredient 配料名称
 * @return int 包含返回1，不包含返回0
 */
int recipe_has_ingredient(Recipe *recipe, const char *ingredient);

#endif // RECIPE_H
