/**
 * @file recipe_file.h
 * @author 成员C姓名
 * @brief 菜品文件操作接口
 * @date 2024-01-15
 */

#ifndef RECIPE_FILE_H
#define RECIPE_FILE_H

#include "recipe_manage.h"

// ==================== 文件操作API ====================

/**
 * @brief 保存菜品数据到二进制文件
 * 
 * @param manager 菜品管理器
 * @param filename 文件名
 * @return int 成功返回0，失败返回-1
 */
int manager_save_to_file(RecipeManager *manager, const char *filename);

/**
 * @brief 从二进制文件加载菜品数据
 * 
 * @param manager 菜品管理器（必须为空）
 * @param filename 文件名
 * @return int 成功返回0，失败返回-1
 */
int manager_load_from_file(RecipeManager *manager, const char *filename);

#endif // RECIPE_FILE_H