/**
 * @file test_recipe.c
 * @brief 菜品管理系统测试脚本
 */

#include "recipe_system.h"

int main() {
    printf("=== 菜品管理系统测试 ===\n");
    
    // 创建管理器
    RecipeManager *manager = manager_create();
    if (!manager) {
        fprintf(stderr, "创建管理器失败\n");
        return 1;
    }
    
    printf("✅ 创建管理器成功\n");
    
    // 创建测试菜品
    Recipe *recipe = recipe_create(0, "宫保鸡丁", "川菜");
    if (!recipe) {
        fprintf(stderr, "创建菜品失败\n");
        manager_destroy(manager);
        return 1;
    }
    
    // 设置菜品属性
    recipe_set_prep_time(recipe, 10);
    recipe_set_cook_time(recipe, 15);
    recipe_set_difficulty(recipe, 3);
    
    // 添加配料
    recipe_add_ingredient(recipe, "鸡肉丁");
    recipe_add_ingredient(recipe, "花生米");
    recipe_add_ingredient(recipe, "干辣椒");
    recipe_add_ingredient(recipe, "青椒");
    
    printf("✅ 创建菜品成功\n");
    
    // 添加到管理器
    if (manager_add_recipe(manager, recipe) != 0) {
        fprintf(stderr, "添加菜品失败\n");
        recipe_destroy(recipe);
        manager_destroy(manager);
        return 1;
    }
    
    printf("✅ 添加菜品到管理器成功\n");
    
    // 显示所有菜品
    printf("\n=== 菜品列表 ===\n");
    manager_display_all(manager);
    
    // 测试查找功能
    Recipe *found = manager_find_by_id(manager, 1);
    if (found) {
        printf("\n✅ 查找菜品成功\n");
        recipe_display(found);
    } else {
        fprintf(stderr, "\n❌ 查找菜品失败\n");
    }
    
    // 测试删除功能
    if (manager_remove_recipe(manager, 1) == 0) {
        printf("\n✅ 删除菜品成功\n");
    } else {
        fprintf(stderr, "\n❌ 删除菜品失败\n");
    }
    
    // 显示删除后的列表
    printf("\n=== 删除后的菜品列表 ===\n");
    manager_display_all(manager);
    
    // 清理资源
    manager_destroy(manager);
    
    printf("\n✅ 所有测试完成\n");
    printf("=== 测试结束 ===\n");
    
    return 0;
}
