/**
 * @file linked_list.c
 * @author 组长姓名
 * @brief 通用双向链表实现
 */
#include "linked_list.h"

// 创建新链表
List* list_create(void (*free_func)(void *), 
                  int (*cmp_func)(void *, void *),
                  void (*print_func)(void *)) {
    
    List *list = (List *)malloc(sizeof(List));
    if (!list) {
        fprintf(stderr, "内存分配失败: list_create\n");
        return NULL;
    }
    
    list->head = NULL;
    list->tail = NULL;
    list->size = 0;
    list->free_data = free_func;
    list->compare = cmp_func;
    list->print = print_func;
    
    return list;
}

// 销毁链表
void list_destroy(List *list) {
    if (!list) return;
    
    ListNode *current = list->head;
    while (current) {
        ListNode *next = current->next;
        
        // 释放节点数据
        if (list->free_data && current->data) {
            list->free_data(current->data);
        }
        
        // 释放节点本身
        free(current);
        current = next;
    }
    
    free(list);
}

// 在尾部添加数据
int list_append(List *list, void *data) {
    if (!list || !data) return -1;
    
    ListNode *new_node = (ListNode *)malloc(sizeof(ListNode));
    if (!new_node) {
        fprintf(stderr, "内存分配失败: list_append\n");
        return -1;
    }
    
    new_node->data = data;
    new_node->next = NULL;
    new_node->prev = list->tail;
    
    if (list->tail) {
        list->tail->next = new_node;
    } else {
        // 链表为空
        list->head = new_node;
    }
    
    list->tail = new_node;
    list->size++;
    
    return 0;
}



// 删除指定位置节点
void* list_remove(List *list, int position) {
    if (!list || position < 0 || position >= list->size) {
        return NULL;
    }
    
    ListNode *to_remove;
    
    // 找到要删除的节点
    if (position == 0) {
        to_remove = list->head;
        list->head = to_remove->next;
        if (list->head) {
            list->head->prev = NULL;
        } else {
            list->tail = NULL; // 链表变空
        }
    } else if (position == list->size - 1) {
        to_remove = list->tail;
        list->tail = to_remove->prev;
        list->tail->next = NULL;
    } else {
        to_remove = list->head;
        for (int i = 0; i < position; i++) {
            to_remove = to_remove->next;
        }
        
        to_remove->prev->next = to_remove->next;
        to_remove->next->prev = to_remove->prev;
    }
    
    void *data = to_remove->data;
    free(to_remove);
    list->size--;
    
    return data;
}

// 获取指定位置数据
void* list_get(List *list, int position) {
    if (!list || position < 0 || position >= list->size) {
        return NULL;
    }
    
    ListNode *current = list->head;
    for (int i = 0; i < position; i++) {
        current = current->next;
    }
    
    return current->data;
}

// 获取链表大小
int list_size(List *list) {
    return list ? list->size : 0;
}



// 遍历链表
void list_foreach(List *list, void (*action)(void *)) {
    if (!list || !action) return;
    
    ListNode *current = list->head;
    while (current) {
        action(current->data);
        current = current->next;
    }
}

// 打印链表
void list_print(List *list) {
    if (!list || !list->print) {
        printf("无内容\n");
        return;
    }
    
    printf("[");
    
    ListNode *current = list->head;
    while (current) {
        list->print(current->data);
        if (current->next) printf(", ");
        current = current->next;
    }
    
    printf("]\n");
}

// 链表排序（冒泡排序）
void list_sort_up(List *list)
{
	//如果头结点或者比较函数为空，数据节点小于2，直接结束函数
    if (list == NULL && list->compare == NULL && list->size < 2) return;
    
    int flag_isok;//用来标志链表是否有序,默认为0，发生交换置1，当遍历一遍无须交换则说明已经有序

    do {
        flag_isok = 0;
        ListNode *cur = list->head;
        
        while (cur && cur->next)
		{
			//调用cmp函数，如果当前元素>下一个元素，则交换两者位置
            if (list->compare(cur->data, cur->next->data) > 0)
			{
                void *temp = cur->data;
                cur->data = cur->next->data;
                cur->next->data = temp;
                flag_isok = 1;
            }
            cur = cur->next;
        }
    } while (flag_isok);
}
// 链表排序（冒泡排序）
void list_sort_down(List *list)
{
	//如果头结点或者比较函数为空，数据节点小于2，直接结束函数
    if (list == NULL && list->compare == NULL && list->size < 2) return;
    
    int flag_isok;//用来标志链表是否有序,默认为0，发生交换置1，当遍历一遍无须交换则说明已经有序

    do {
        flag_isok = 0;
        ListNode *cur = list->head;
        
        while (cur && cur->next)
		{
			//调用cmp函数，如果当前元素>下一个元素，则交换两者位置
            if (list->compare(cur->data, cur->next->data) < 0)
			{
                void *temp = cur->data;
                cur->data = cur->next->data;
                cur->next->data = temp;
                flag_isok = 1;
            }
            cur = cur->next;
        }
    } while (flag_isok);
}

