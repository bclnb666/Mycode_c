/**
 * @file recipe_sort.c
 * @author 成员D姓名
 * @brief 排序功能实现
 */

#include "recipe_system.h"
#include <string.h>

// 比较函数：按ID
static int compare_id(void *a, void *b) {
    Recipe *ra = (Recipe *)a;
    Recipe *rb = (Recipe *)b;
    return ra->id - rb->id;
}

// 比较函数：按名称
static int compare_name(void *a, void *b) {
    Recipe *ra = (Recipe *)a;
    Recipe *rb = (Recipe *)b;
    return strcmp(ra->name, rb->name);
}

// 比较函数：按预计时间
static int compare_time(void *a, void *b) {
    Recipe *ra = (Recipe *)a;
    Recipe *rb = (Recipe *)b;
    return ra->estimated_time - rb->estimated_time;
}

// 比较函数：按难度
static int compare_difficulty(void *a, void *b) {
    Recipe *ra = (Recipe *)a;
    Recipe *rb = (Recipe *)b;
    return ra->difficulty - rb->difficulty;
}

// 比较函数：按分类然后按名称
static int compare_category_name(void *a, void *b) {
    Recipe *ra = (Recipe *)a;
    Recipe *rb = (Recipe *)b;
    
    int cmp = strcmp(ra->category, rb->category);//先比较分类
    if (cmp != 0) return cmp;
    
	//再比较名字
    return strcmp(ra->name, rb->name);
}

// 按ID排序
void manager_sort_by_id(RecipeManager *manager,int mode)
{
    if (manager == NULL) return;
    
    manager->recipes->compare = compare_id;
	if(mode == 0)
	{
    	list_sort_up(manager->recipes);
    	printf("已按ID升序排序\n");
	}else
	{

    	list_sort_down(manager->recipes);
    	printf("已按ID降序排序\n");
	}
}

// 按名称排序
void manager_sort_by_name(RecipeManager *manager,int mode)
{
    if (manager == NULL) return;
    
    manager->recipes->compare = compare_name;
	if(mode == 0)
	{
    	list_sort_up(manager->recipes);
    	printf("已按ID升序排序\n");
	}else
	{

    	list_sort_down(manager->recipes);
    	printf("已按ID降序排序\n");
	}
}

// 按总时间排序
void manager_sort_by_total_time(RecipeManager *manager,int mode)
{
    if (manager == NULL) return;
    
    manager->recipes->compare = compare_time;
	if(mode == 0)
	{
    	list_sort_up(manager->recipes);
    	printf("已按ID升序排序\n");
	}else
	{

    	list_sort_down(manager->recipes);
    	printf("已按ID降序排序\n");
	}
}

// 按难度排序
void manager_sort_by_difficulty(RecipeManager *manager,int mode)
{
    if (manager == NULL) return;
    
    manager->recipes->compare = compare_difficulty;
    
	if(mode == 0)
	{
    	list_sort_up(manager->recipes);
    	printf("已按ID升序排序\n");
	}else
	{

    	list_sort_down(manager->recipes);
    	printf("已按ID降序排序\n");
	}
}

// 按分类然后按名称排序
void manager_sort_by_category_then_name(RecipeManager *manager,int mode) 
{
    if (manager == NULL) return;
    
    manager->recipes->compare = compare_category_name;
   
	if(mode == 0)
	{
    	list_sort_up(manager->recipes);
    	printf("已按ID升序排序\n");
	}else
	{

    	list_sort_down(manager->recipes);
    	printf("已按ID降序排序\n");
	}
}
