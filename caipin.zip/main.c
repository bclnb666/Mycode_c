/**
 * @file main.c
 * @author 成员E姓名
 * @brief 菜品管理系统主程序
 * @date 2024-01-15
 * 
 * 程序入口点，负责协调所有模块
 */

#include "recipe_system.h"

int main() {
    // 创建菜品管理器
    RecipeManager *manager = manager_create();
    if (!manager) {
        fprintf(stderr, "无法创建菜品管理器！\n");
        return 1;
    }
    
    printf("欢迎使用菜品配料管理系统！\n");
    
    // 尝试从默认文件加载数据
    if (manager_load_from_file(manager, "recipes.dat") != 0) {
        printf("无法加载数据文件，将创建新文件\n");
    }
    
    int running = 1;
    while (running) {
        ui_show_menu();
        
        int choice;
        if (scanf("%d", &choice) != 1) {
            // 输入错误，清空缓冲区
            while (getchar() != '\n');
            continue;
        }
        getchar();  // 清除换行符
        
        switch (choice) {
            case 1:
                ui_add_recipe(manager);
                break;
                
            case 2:
                ui_clear_screen();
                printf("=== 所有菜品 ===\n");
                manager_display_all(manager);
                ui_pause();
                break;
                
            case 3:
                // 合并查找和查看详情功能
                ui_search_recipe(manager);
                break;
                
            case 4:
                ui_modify_recipe(manager);
                break;
                
            case 5:
                ui_delete_recipe(manager);
                break;
                
            case 6:
                ui_sort_recipes(manager);
                break;
                
            case 7:
                ui_file_operations(manager);
                break;
                
            case 8:
                ui_add_sample_recipes(manager);
                break;
                
            case 0:
                // 退出前保存数据
                manager_save_to_file(manager, "recipes.dat");
                printf("数据已保存，再见！\n");
                running = 0;
                break;
                
            default:
                printf("无效的选择，请重新输入！\n");
                ui_pause();
                break;
        }
    }
    
    // 清理资源
    manager_destroy(manager);
    
    return 0;
}
