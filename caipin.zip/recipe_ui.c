/**
 * @file recipe_ui.c
 * @author 成员E姓名
 * @brief 用户界面实现
 */

#include "recipe_system.h"
#include <ctype.h>
#include <stdlib.h>

#ifdef _WIN32
    #include <windows.h>
    #define CLEAR_SCREEN "cls"
#else
    #include <unistd.h>
    #define CLEAR_SCREEN "clear"
#endif

// 清屏函数
void ui_clear_screen() {
    system(CLEAR_SCREEN);
}

// 暂停等待
void ui_pause() {
    printf("\n按回车键继续...");
    while (getchar() != '\n');  // 清空输入缓冲区
    getchar();  // 等待回车
}

// 显示主菜单
void ui_show_menu() {
    ui_clear_screen();
    printf("========================================\n");
    printf("       菜品配料管理系统 v1.0\n");
    printf("========================================\n");
    printf("1. 添加新菜品\n");
    printf("2. 显示所有菜品\n");
    printf("3. 查找/查看详情\n");
    printf("4. 修改菜品\n");
    printf("5. 删除菜品\n");
    printf("6. 排序菜品\n");
    printf("7. 文件操作\n");
    printf("8. 添加示例菜品\n");
    printf("0. 退出系统\n");
    printf("========================================\n");
    printf("请选择操作 (0-8): ");
}

// 添加菜品界面
void ui_add_recipe(RecipeManager *manager) {
    ui_clear_screen();
    printf("=== 添加新菜品 ===\n");
    
    char name[MAX_NAME_LEN];
    char category[MAX_CATEGORY_LEN];
    
    printf("请输入菜品名称: ");
    fgets(name, sizeof(name), stdin);
    name[strcspn(name, "\n")] = '\0';
    
    printf("请输入菜品分类: ");
    fgets(category, sizeof(category), stdin);
    category[strcspn(category, "\n")] = '\0';
    
    // 创建菜品
    Recipe *recipe = recipe_create(0, name, category);
    if (!recipe) {
        printf("创建菜品失败！\n");
        ui_pause();
        return;
    }
    
    // 输入预计时间
    printf("请输入预计时间(分钟): ");
    int estimated_time;
    scanf("%d", &estimated_time);
    getchar();  // 清除换行符
    recipe_set_estimated_time(recipe, estimated_time);
    
    // 输入难度
    printf("请输入难度等级(1-5): ");
    int difficulty;
    scanf("%d", &difficulty);
    getchar();
    while (difficulty < 1 || difficulty > 5) {
        printf("难度必须在1-5之间，请重新输入: ");
        scanf("%d", &difficulty);
        getchar();
    }
    recipe_set_difficulty(recipe, difficulty);
    
    // 输入配料（输入空行结束）
    printf("请输入配料（输入空行结束）: \n");
    int ing_count = 0;
    char ingredient[MAX_INGREDIENT_LEN];
    
    while (1) {
        printf("配料%d: ", ing_count + 1);
        fgets(ingredient, sizeof(ingredient), stdin);
        ingredient[strcspn(ingredient, "\n")] = '\0';
        
        // 输入空行结束
        if (ingredient[0] == '\0') {
            break;
        }
        
        // 限制最大配料数量
        if (ing_count >= MAX_INGREDIENTS) {
            printf("⚠️  配料数量已达上限(%d)\n", MAX_INGREDIENTS);
            break;
        }
        
        recipe_add_ingredient(recipe, ingredient);
        ing_count++;
    }
    
    // 添加到管理器
    if (manager_add_recipe(manager, recipe) == 0) {
        printf("\n✅ 菜品添加成功！ID: %d\n", recipe->id);
        recipe_display(recipe);
    } else {
        recipe_destroy(recipe);
        printf("\n❌ 菜品添加失败！\n");
    }
    
    ui_pause();
}

// 查找菜品界面
void ui_search_recipe(RecipeManager *manager) {
    ui_clear_screen();
    printf("=== 查找菜品 ===\n");
    printf("1. 按名称查找\n");
    printf("2. 按分类查找\n");
    printf("3. 按配料查找\n");
    printf("4. 按时间范围查找\n");
    printf("5. 按难度查找\n");
    printf("6. 高级查找\n");
    printf("请选择查找方式: ");
    
    int choice;
    scanf("%d", &choice);
    getchar();
    
    List *results = NULL;
    char input[100];
    int num1, num2;
    
    switch (choice) {
        case 1:
            printf("请输入菜品名称(支持*通配符): ");
            fgets(input, sizeof(input), stdin);
            input[strcspn(input, "\n")] = '\0';
            results = manager_search_by_name(manager, input);
            break;
            
        case 2:
            printf("请输入分类: ");
            fgets(input, sizeof(input), stdin);
            input[strcspn(input, "\n")] = '\0';
            results = manager_search_by_category(manager, input);
            break;
            
        case 3:
            printf("请输入配料: ");
            fgets(input, sizeof(input), stdin);
            input[strcspn(input, "\n")] = '\0';
            results = manager_search_by_ingredient(manager, input);
            break;
            
        case 4:
            printf("请输入最短时间(分钟): ");
            scanf("%d", &num1);
            printf("请输入最长时间(分钟): ");
            scanf("%d", &num2);
            getchar();
            results = manager_search_by_time(manager, num1, num2);
            break;
            
        case 5:
            printf("请输入难度等级(1-5): ");
            scanf("%d", &num1);
            getchar();
            results = manager_search_by_difficulty(manager, num1);
            break;
            
        case 6:
            printf("请输入查找条件(格式: 名称=鱼香,分类=川菜,难度=3): ");
            fgets(input, sizeof(input), stdin);
            input[strcspn(input, "\n")] = '\0';
            results = manager_search_advanced(manager, input);
            break;
            
        default:
            printf("无效的选择！\n");
            ui_pause();
            return;
    }
    
    // 显示查找结果
    if (results && results->size > 0) {
        printf("\n=== 查找结果（共%d个）===\n", results->size);
        list_foreach(results, (void (*)(void *))recipe_display);
    } else {
        printf("\n未找到符合条件的菜品\n");
    }
    
    // 释放结果链表（不释放菜品数据）
    if (results) {
        results->free_data = NULL;  // 防止释放菜品数据
        list_destroy(results);
    }
    
    ui_pause();
}

// 修改菜品界面
void ui_modify_recipe(RecipeManager *manager) {
    ui_clear_screen();
    printf("=== 修改菜品 ===\n");
    
    printf("请输入要修改的菜品ID: ");
    int id;
    scanf("%d", &id);
    getchar();
    
    Recipe *old_recipe = manager_find_by_id(manager, id);
    if (!old_recipe) {
        printf("未找到ID为 %d 的菜品！\n", id);
        ui_pause();
        return;
    }
    
    // 显示原信息
    printf("\n原菜品信息:\n");
    recipe_display(old_recipe);
    printf("\n--- 输入新的菜品信息 ---\n");
    
    // 直接输入所有新信息
    char name[MAX_NAME_LEN];
    char category[MAX_CATEGORY_LEN];
    
    printf("菜品名称: ");
    fgets(name, sizeof(name), stdin);
    name[strcspn(name, "\n")] = '\0';
    
    printf("菜品分类: ");
    fgets(category, sizeof(category), stdin);
    category[strcspn(category, "\n")] = '\0';
    
    // 创建新菜品
    Recipe *new_recipe = recipe_create(id, name, category);
    if (!new_recipe) {
        printf("创建新菜品失败！\n");
        ui_pause();
        return;
    }
    
    // 输入预计时间
    printf("预计时间(分钟): ");
    int estimated_time;
    scanf("%d", &estimated_time);
    getchar();
    recipe_set_estimated_time(new_recipe, estimated_time);
    
    // 输入难度
    printf("难度等级(1-5): ");
    int difficulty;
    scanf("%d", &difficulty);
    getchar();
    while (difficulty < 1 || difficulty > 5) {
        printf("难度必须在1-5之间，请重新输入: ");
        scanf("%d", &difficulty);
        getchar();
    }
    recipe_set_difficulty(new_recipe, difficulty);
    
    // 输入配料（输入空行结束）
    printf("配料（输入空行结束）: \n");
    int ing_count = 0;
    char ingredient[MAX_INGREDIENT_LEN];
    
    while (1) {
        printf("配料%d: ", ing_count + 1);
        fgets(ingredient, sizeof(ingredient), stdin);
        ingredient[strcspn(ingredient, "\n")] = '\0';
        
        if (ingredient[0] == '\0') {
            break;
        }
        
        if (ing_count >= MAX_INGREDIENTS) {
            printf("⚠️  配料数量已达上限(%d)\n", MAX_INGREDIENTS);
            break;
        }
        
        recipe_add_ingredient(new_recipe, ingredient);
        ing_count++;
    }
    
    // 执行修改
    if (manager_modify_recipe(manager, id, new_recipe) == 0) {
        printf("\n✅ 菜品修改成功！\n");
        recipe_display(manager_find_by_id(manager, id));
    } else {
        printf("\n❌ 菜品修改失败！\n");
        recipe_destroy(new_recipe);
    }
    
    ui_pause();
}

// 删除菜品界面
void ui_delete_recipe(RecipeManager *manager) {
    ui_clear_screen();
    printf("=== 删除菜品 ===\n");
    
    printf("请输入要删除的菜品ID: ");
    int id;
    scanf("%d", &id);
    getchar();
    
    printf("确定要删除ID为 %d 的菜品吗？(y/n): ", id);
    char confirm;
    scanf(" %c", &confirm);
    getchar();
    
    if (confirm == 'y' || confirm == 'Y') {
        if (manager_remove_recipe(manager, id) == 0) {
            printf("✅ 菜品删除成功！\n");
        } else {
            printf("❌ 菜品删除失败！\n");
        }
    } else {
        printf("删除已取消\n");
    }
    
    ui_pause();
}

// 排序菜品界面
void ui_sort_recipes(RecipeManager *manager) {
    ui_clear_screen();
    printf("=== 排序菜品 ===\n");
    printf("1. 按ID排序\n");
    printf("2. 按名称排序\n");
    printf("3. 按总时间排序\n");
    printf("4. 按难度排序\n");
    printf("5. 按分类+名称排序\n");
    printf("请选择排序方式: ");
    
    int choice,mode;
    scanf("%d", &choice);
    getchar();
    
     switch (choice) {
        case 1:
			printf("请选择排序方式(0-升序,1-降序)：");
			scanf("%d",&mode);
            manager_sort_by_id(manager,mode);
            break;
        case 2:
			printf("请选择排序方式(0-升序,1-降序)：");
			scanf("%d",&mode);
            manager_sort_by_name(manager,mode);
            break;
        case 3:
			printf("请选择排序方式(0-升序,1-降序)：");
			scanf("%d",&mode);
            manager_sort_by_total_time(manager,mode);
            break;
        case 4:
			printf("请选择排序方式(0-升序,1-降序)：");
			scanf("%d",&mode);
            manager_sort_by_difficulty(manager,mode);
            break;
        case 5:
			printf("请选择排序方式(0-升序,1-降序)：");
			scanf("%d",&mode);
            manager_sort_by_category_then_name(manager,mode);
            break;
        default:
            printf("无效的选择！\n");
            ui_pause();
            return;
    }   
    // 显示排序结果
    printf("\n排序后的菜品列表:\n");
    manager_display_all(manager);
    
    ui_pause();
}

// 文件操作界面
void ui_file_operations(RecipeManager *manager) {
    ui_clear_screen();
    printf("=== 文件操作 ===\n");
    printf("1. 保存数据\n");
    printf("2. 加载数据\n");
    printf("请选择: ");
    
    int choice;
    scanf("%d", &choice);
    getchar();
    
    char filename[100];
    
    switch (choice) {
        case 1:
            printf("文件名(默认: recipes.dat): ");
            fgets(filename, sizeof(filename), stdin);
            filename[strcspn(filename, "\n")] = '\0';
            if (filename[0] == '\0') strcpy(filename, "recipes.dat");
            manager_save_to_file(manager, filename);
            break;
            
        case 2:
            printf("文件名(默认: recipes.dat): ");
            fgets(filename, sizeof(filename), stdin);
            filename[strcspn(filename, "\n")] = '\0';
            if (filename[0] == '\0') strcpy(filename, "recipes.dat");
            manager_load_from_file(manager, filename);
            break;
            
        default:
            printf("无效的选择！\n");
    }
    
    ui_pause();
}

// 查看菜品详情界面
void ui_show_recipe_detail(RecipeManager *manager) {
    ui_clear_screen();
    printf("=== 查看菜品详情 ===\n");
    
    printf("请输入菜品ID: ");
    int id;
    scanf("%d", &id);
    getchar();
    
    Recipe *recipe = manager_find_by_id(manager, id);
    if (recipe) {
        recipe_display(recipe);
    } else {
        printf("未找到ID为 %d 的菜品！\n", id);
    }
    
    ui_pause();
}

// 显示统计信息
void ui_show_statistics(RecipeManager *manager) {
    ui_clear_screen();
    printf("=== 统计信息 ===\n");
    
    int total = manager_get_count(manager);
    printf("菜品总数: %d\n", total);
    
    if (total == 0) {
        ui_pause();
        return;
    }
    
    // 按分类统计
    printf("\n按分类统计:\n");
    List *categories = list_create(free, 
                                 (int (*)(void *, void *))strcmp,
                                 NULL);
    
    for (int i = 0; i < total; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        
        // 检查分类是否已记录
        int found = 0;
        for (int j = 0; j < categories->size; j++) {
            char *cat = (char *)list_get(categories, j);
            if (strcmp(cat, recipe->category) == 0) {
                found = 1;
                break;
            }
        }
        
        if (!found) {
            char *cat_copy = strdup(recipe->category);
            list_append(categories, cat_copy);
        }
    }
    
    // 统计每个分类的数量
    for (int i = 0; i < categories->size; i++) {
        char *category = (char *)list_get(categories, i);
        int count = 0;
        int total_time = 0;
        
        for (int j = 0; j < total; j++) {
            Recipe *recipe = (Recipe *)list_get(manager->recipes, j);
            if (strcmp(recipe->category, category) == 0) {
                count++;
                total_time += recipe->estimated_time;
            }
        }
        
        float avg_time = count > 0 ? (float)total_time / count : 0;
        printf("  %s: %d个菜品，平均用时%.1f分钟\n", 
               category, count, avg_time);
    }
    
    list_destroy(categories);
    
    // 统计难度分布
    printf("\n按难度统计:\n");
    for (int level = 1; level <= 5; level++) {
        int count = 0;
        for (int i = 0; i < total; i++) {
            Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
            if (recipe->difficulty == level) {
                count++;
            }
        }
        printf("  难度%d: %d个菜品\n", level, count);
    }
    
    // 平均预计时间
    int total_estimated = 0;
    for (int i = 0; i < total; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        total_estimated += recipe->estimated_time;
    }
    
    printf("\n时间统计:\n");
    printf("  平均预计时间: %.1f分钟\n", (float)total_estimated / total);
    
    ui_pause();
}

// 添加示例菜品
void ui_add_sample_recipes(RecipeManager *manager) {
    ui_clear_screen();
    printf("=== 添加示例菜品 ===\n");
    
    // 示例菜品1: 鱼香肉丝
    Recipe *recipe1 = recipe_create(0, "鱼香肉丝", "川菜");
    recipe_set_estimated_time(recipe1, 30);
    recipe_set_difficulty(recipe1, 3);
    recipe_add_ingredient(recipe1, "猪肉");
    recipe_add_ingredient(recipe1, "木耳");
    recipe_add_ingredient(recipe1, "胡萝卜");
    recipe_add_ingredient(recipe1, "青椒");
    manager_add_recipe(manager, recipe1);
    
    // 示例菜品2: 西红柿炒蛋
    Recipe *recipe2 = recipe_create(0, "西红柿炒蛋", "家常菜");
    recipe_set_estimated_time(recipe2, 18);
    recipe_set_difficulty(recipe2, 1);
    recipe_add_ingredient(recipe2, "西红柿");
    recipe_add_ingredient(recipe2, "鸡蛋");
    recipe_add_ingredient(recipe2, "葱");
    manager_add_recipe(manager, recipe2);
    
    // 示例菜品3: 红烧肉
    Recipe *recipe3 = recipe_create(0, "红烧肉", "鲁菜");
    recipe_set_estimated_time(recipe3, 90);
    recipe_set_difficulty(recipe3, 4);
    recipe_add_ingredient(recipe3, "五花肉");
    recipe_add_ingredient(recipe3, "生姜");
    recipe_add_ingredient(recipe3, "冰糖");
    recipe_add_ingredient(recipe3, "料酒");
    manager_add_recipe(manager, recipe3);
    
    // 示例菜品4: 蔬菜沙拉
    Recipe *recipe4 = recipe_create(0, "蔬菜沙拉", "西餐");
    recipe_set_estimated_time(recipe4, 15);
    recipe_set_difficulty(recipe4, 1);
    recipe_add_ingredient(recipe4, "生菜");
    recipe_add_ingredient(recipe4, "番茄");
    recipe_add_ingredient(recipe4, "黄瓜");
    recipe_add_ingredient(recipe4, "沙拉酱");
    manager_add_recipe(manager, recipe4);
    
    printf("✅ 已添加4个示例菜品！\n");
    printf("  1. 鱼香肉丝（川菜）\n");
    printf("  2. 西红柿炒鸡蛋（家常菜）\n");
    printf("  3. 红烧肉（本帮菜）\n");
    printf("  4. 蔬菜沙拉（西餐）\n");
    
    ui_pause();
}
