/**
 * @file recipe_search.h
 * @author 成员D姓名
 * @brief 菜品查找功能
 * @date 2024-01-15
 */

#ifndef RECIPE_SEARCH_H
#define RECIPE_SEARCH_H

#include "recipe_manage.h"

// ==================== 查找API ====================

/**
 * @brief 按名称查找菜品（支持模糊查找）
 * 
 * @param manager 菜品管理器
 * @param name 菜品名称（支持*通配符）
 * @return List* 返回包含查找结果的链表，需要调用者释放
 */
List* manager_search_by_name(RecipeManager *manager, const char *name);

/**
 * @brief 按分类查找菜品
 * 
 * @param manager 菜品管理器
 * @param category 分类名称
 * @return List* 返回包含查找结果的链表，需要调用者释放
 */
List* manager_search_by_category(RecipeManager *manager, const char *category);

/**
 * @brief 按配料查找菜品
 * 
 * @param manager 菜品管理器
 * @param ingredient 配料名称
 * @return List* 返回包含查找结果的链表，需要调用者释放
 */
List* manager_search_by_ingredient(RecipeManager *manager, const char *ingredient);

/**
 * @brief 按时间范围查找菜品
 * 
 * @param manager 菜品管理器
 * @param min_time 最短总时间
 * @param max_time 最长总时间
 * @return List* 返回包含查找结果的链表，需要调用者释放
 */
List* manager_search_by_time(RecipeManager *manager, int min_time, int max_time);

/**
 * @brief 按难度查找菜品
 * 
 * @param manager 菜品管理器
 * @param difficulty 难度等级
 * @return List* 返回包含查找结果的链表，需要调用者释放
 */
List* manager_search_by_difficulty(RecipeManager *manager, int difficulty);

/**
 * @brief 组合条件查找
 * 
 * @param manager 菜品管理器
 * @param conditions 条件字符串，格式："名称=xxx,分类=xxx,难度=3"
 * @return List* 返回包含查找结果的链表，需要调用者释放
 */
List* manager_search_advanced(RecipeManager *manager, const char *conditions);

#endif // RECIPE_SEARCH_H