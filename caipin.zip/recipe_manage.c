/**
 * @file recipe_manage.c
 * @author 成员B姓名
 * @brief 菜品管理系统实现
 */

#include "recipe_system.h"

// 创建管理器
RecipeManager* manager_create() {
    RecipeManager *manager = (RecipeManager *)malloc(sizeof(RecipeManager));
    if (!manager) {
        fprintf(stderr, "内存分配失败: manager_create\n");
        return NULL;
    }
    
    manager->recipes = list_create(recipe_destroy, recipe_compare, recipe_print);
    if (!manager->recipes) {
        free(manager);
        return NULL;
    }
    
    manager->next_id = 1;  // 从1开始
    return manager;
}

// 销毁管理器
void manager_destroy(RecipeManager *manager) {
    if (!manager) return;
    
    if (manager->recipes) {
        list_destroy(manager->recipes);
    }
    
    free(manager);
}

// 添加菜品
int manager_add_recipe(RecipeManager *manager, Recipe *recipe) {
    if (!manager || !recipe) return -1;
    
    // 检查ID是否重复
    if (manager_find_by_id(manager, recipe->id)) {
        fprintf(stderr, "菜品ID %d 已存在\n", recipe->id);
        return -1;
    }
    
    // 自动分配ID（如果id为0）
    if (recipe->id == 0) {
        recipe->id = manager->next_id++;
    } else if (recipe->id >= manager->next_id) {
        manager->next_id = recipe->id + 1;
    }
    
    return list_append(manager->recipes, recipe);
}

// 删除菜品
int manager_remove_recipe(RecipeManager *manager, int id) {
    if (!manager) return -1;
    
    // 查找菜品位置
    for (int i = 0; i < manager->recipes->size; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        if (recipe && recipe->id == id) {
            void *removed = list_remove(manager->recipes, i);
            if (removed) {
                recipe_destroy(removed);
                return 0;
            }
            break;
        }
    }
    
    printf("未找到ID为 %d 的菜品\n", id);
    return -1;
}

// 修改菜品
int manager_modify_recipe(RecipeManager *manager, int id, Recipe *new_recipe) {
    if (!manager || !new_recipe) return -1;
    
    Recipe *old_recipe = manager_find_by_id(manager, id);
    if (!old_recipe) {
        printf("未找到ID为 %d 的菜品\n", id);
        return -1;
    }
    
    // 更新菜品信息（不改变ID）
    strncpy(old_recipe->name, new_recipe->name, MAX_NAME_LEN - 1);
    old_recipe->name[MAX_NAME_LEN - 1] = '\0';
    
    strncpy(old_recipe->category, new_recipe->category, MAX_CATEGORY_LEN - 1);
    old_recipe->category[MAX_CATEGORY_LEN - 1] = '\0';
    
    old_recipe->estimated_time = new_recipe->estimated_time;
    old_recipe->difficulty = new_recipe->difficulty;
    
    // 清空旧配料，添加新配料
    list_destroy(old_recipe->ingredients);
    old_recipe->ingredients = new_recipe->ingredients;
    
    // 防止new_recipe被重复释放
    new_recipe->ingredients = NULL;
    
    printf("菜品 %d 修改成功\n", id);
    return 0;
}

// 根据ID查找
Recipe* manager_find_by_id(RecipeManager *manager, int id) {
    if (!manager) return NULL;
    
    for (int i = 0; i < manager->recipes->size; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        if (recipe && recipe->id == id) {
            return recipe;
        }
    }
    
    return NULL;
}

// 获取菜品数量
int manager_get_count(RecipeManager *manager) {
    return manager ? manager->recipes->size : 0;
}

// 显示所有菜品
void manager_display_all(RecipeManager *manager) {
    if (!manager || manager->recipes->size == 0) {
        printf("当前没有菜品\n");
        return;
    }
    
    printf("=== 菜品列表（共%d个）===\n", manager->recipes->size);
    list_foreach(manager->recipes, (void (*)(void *))recipe_display);
    printf("========================\n");
}

// 清空所有菜品
void manager_clear_all(RecipeManager *manager) {
    if (!manager) return;
    
    list_destroy(manager->recipes);
    manager->recipes = list_create(recipe_destroy, recipe_compare, recipe_print);
    manager->next_id = 1;
    
    printf("已清空所有菜品\n");
}
