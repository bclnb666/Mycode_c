/**
 * @file recipe_file.c
 * @author 成员C姓名
 * @brief 文件持久化实现
 */

#include "recipe_system.h"
#include <ctype.h>

// 保存到二进制文件
int manager_save_to_file(RecipeManager *manager, const char *filename) {
    if (!manager || !filename) return -1;
    
    FILE *fp = fopen(filename, "wb");
    if (!fp) {
        fprintf(stderr, "无法打开文件: %s\n", filename);
        return -1;
    }
    
    // 写入文件头（魔法数字和版本）
    const char magic[] = "RECIPEv1.0";
    fwrite(magic, sizeof(char), 20, fp);
    
    // 写入菜品数量
    int count = manager_get_count(manager);
    fwrite(&count, sizeof(int), 1, fp);
    fwrite(&manager->next_id, sizeof(int), 1, fp);
    
    // 写入每个菜品
    for (int i = 0; i < count; i++) {
        Recipe *recipe = (Recipe *)list_get(manager->recipes, i);
        
        // 写入菜品基本信息
        fwrite(&recipe->id, sizeof(int), 1, fp);
        fwrite(recipe->name, sizeof(char), MAX_NAME_LEN, fp);
        fwrite(recipe->category, sizeof(char), MAX_CATEGORY_LEN, fp);
        fwrite(&recipe->estimated_time, sizeof(int), 1, fp);
        fwrite(&recipe->difficulty, sizeof(int), 1, fp);
        
        // 写入配料数量
        int ing_count = recipe->ingredients->size;
        fwrite(&ing_count, sizeof(int), 1, fp);
        
        // 写入每个配料
        ListNode *node = recipe->ingredients->head;
        while (node) {
            char *ingredient = (char *)node->data;
            int len = strlen(ingredient) + 1;
            fwrite(&len, sizeof(int), 1, fp);
            fwrite(ingredient, sizeof(char), len, fp);
            node = node->next;
        }
    }
    
    fclose(fp);
    printf("数据已保存到文件: %s (共%d个菜品)\n", filename, count);
    return 0;
}

// 从二进制文件加载
int manager_load_from_file(RecipeManager *manager, const char *filename) {
    if (!manager || !filename) return -1;
    
    FILE *fp = fopen(filename, "rb");
    if (!fp) {
        fprintf(stderr, "无法打开文件: %s\n", filename);
        return -1;
    }
    
    // 验证文件头
    char magic[20];
    fread(magic, sizeof(char), 20, fp);
    if (strncmp(magic, "RECIPEv1.0", 10) != 0) {
        fprintf(stderr, "文件格式错误或版本不兼容\n");
        fclose(fp);
        return -1;
    }
    
    // 清空现有数据
    manager_clear_all(manager);
    
    // 读取菜品数量
    int count;
    fread(&count, sizeof(int), 1, fp);
    fread(&manager->next_id, sizeof(int), 1, fp);
    
    // 读取每个菜品
    for (int i = 0; i < count; i++) {
        Recipe *recipe = (Recipe *)malloc(sizeof(Recipe));
        if (!recipe) {
            fprintf(stderr, "内存分配失败\n");
            fclose(fp);
            return -1;
        }
        
        // 读取基本信息
        fread(&recipe->id, sizeof(int), 1, fp);
        fread(recipe->name, sizeof(char), MAX_NAME_LEN, fp);
        fread(recipe->category, sizeof(char), MAX_CATEGORY_LEN, fp);
        fread(&recipe->estimated_time, sizeof(int), 1, fp);
        fread(&recipe->difficulty, sizeof(int), 1, fp);
        
        // 创建配料链表
        recipe->ingredients = list_create(free, 
                                         (int (*)(void *, void *))strcmp,
                                         NULL);
        
        // 读取配料数量
        int ing_count;
        fread(&ing_count, sizeof(int), 1, fp);
        
        // 读取每个配料
        for (int j = 0; j < ing_count; j++) {
            int len;
            fread(&len, sizeof(int), 1, fp);
            
            char *ingredient = (char *)malloc(len);
            fread(ingredient, sizeof(char), len, fp);
            
            list_append(recipe->ingredients, ingredient);
        }
        
        // 添加到管理器
        list_append(manager->recipes, recipe);
    }
    
    fclose(fp);
    printf("从文件加载了 %d 个菜品\n", count);
    return 0;
}


