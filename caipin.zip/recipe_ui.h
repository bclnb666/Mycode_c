/**
 * @file recipe_ui.h
 * @author 成员E姓名
 * @brief 菜品管理系统用户界面
 * @date 2024-01-15
 */

#ifndef RECIPE_UI_H
#define RECIPE_UI_H

#include "recipe_manage.h"
#include "recipe_file.h"
#include "recipe_search.h"
#include "recipe_sort.h"

// ==================== 用户界面API ====================

/**
 * @brief 显示主菜单
 */
void ui_show_menu();

/**
 * @brief 显示添加菜品界面
 * 
 * @param manager 菜品管理器
 */
void ui_add_recipe(RecipeManager *manager);

/**
 * @brief 显示查找菜品界面
 * 
 * @param manager 菜品管理器
 */
void ui_search_recipe(RecipeManager *manager);

/**
 * @brief 显示修改菜品界面
 * 
 * @param manager 菜品管理器
 */
void ui_modify_recipe(RecipeManager *manager);

/**
 * @brief 显示删除菜品界面
 * 
 * @param manager 菜品管理器
 */
void ui_delete_recipe(RecipeManager *manager);

/**
 * @brief 显示排序菜品界面
 * 
 * @param manager 菜品管理器
 */
void ui_sort_recipes(RecipeManager *manager);

/**
 * @brief 显示文件操作界面
 * 
 * @param manager 菜品管理器
 */
void ui_file_operations(RecipeManager *manager);

/**
 * @brief 显示菜品详情界面
 * 
 * @param manager 菜品管理器
 */
void ui_show_recipe_detail(RecipeManager *manager);

/**
 * @brief 显示统计信息
 * 
 * @param manager 菜品管理器
 */
void ui_show_statistics(RecipeManager *manager);

/**
 * @brief 添加示例菜品（用于测试）
 * 
 * @param manager 菜品管理器
 */
void ui_add_sample_recipes(RecipeManager *manager);

/**
 * @brief 清屏函数（跨平台）
 */
void ui_clear_screen();

/**
 * @brief 暂停等待用户按键
 */
void ui_pause();

#endif // RECIPE_UI_H