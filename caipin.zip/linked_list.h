/**
 * @file linked_list.h
 * @brief 通用双向链表库 - 核心数据结构
 * @date 2024-01-15
 */

#ifndef LINKED_LIST_H
#define LINKED_LIST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// 链表节点结构
typedef struct ListNode {
    void *data;                 // 通用数据指针
    struct ListNode *prev;      // 前驱节点
    struct ListNode *next;      // 后继节点
} ListNode;

// 链表结构
typedef struct List {
    ListNode *head;             // 头节点
    ListNode *tail;             // 尾节点
    int size;                   // 链表大小
    
    // 函数指针 - 实现多态
    void (*free_data)(void *);          // 数据释放函数
    int (*compare)(void *, void *);     // 数据比较函数
    void (*print)(void *);              // 数据打印函数
} List;

// ==================== 链表API ====================

/**
 * @brief 创建新链表
 * 
 * @param free_func 数据释放函数指针
 * @param cmp_func 数据比较函数指针  
 * @param print_func 数据打印函数指针
 * @return List* 成功返回链表指针，失败返回NULL
 */
List* list_create(void (*free_func)(void *), 
                  int (*cmp_func)(void *, void *),
                  void (*print_func)(void *));

/**
 * @brief 销毁链表，释放所有内存
 * 
 * @param list 链表指针
 */
void list_destroy(List *list);

/**
 * @brief 在链表尾部添加数据
 * 
 * @param list 链表指针
 * @param data 要添加的数据
 * @return int 成功返回0，失败返回-1
 */
int list_append(List *list, void *data);

/**
 * @brief 删除指定位置的节点
 * 
 * @param list 链表指针
 * @param position 位置索引
 * @return void* 返回被删除节点的数据，失败返回NULL
 */
void* list_remove(List *list, int position);

/**
 * @brief 获取指定位置的数据
 * 
 * @param list 链表指针
 * @param position 位置索引
 * @return void* 成功返回数据指针，失败返回NULL
 */
void* list_get(List *list, int position);

/**
 * @brief 获取链表大小
 * 
 * @param list 链表指针
 * @return int 链表节点数量
 */
int list_size(List *list);

/**
 * @brief 遍历链表，对每个节点执行操作
 * 
 * @param list 链表指针
 * @param action 操作函数
 */
void list_foreach(List *list, void (*action)(void *));

/**
 * @brief 打印整个链表
 * 
 * @param list 链表指针
 */
void list_print(List *list);

/**
 * @brief 链表排序（冒泡排序）
 * 
 * @param list 链表指针
 */
void list_sort_up(List *list);

void list_sort_down(List *list);


#endif // LINKED_LIST_H
