/**
 * @file recipe_system.h
 * @brief 菜品管理系统统一头文件
 * @date 2025-01-15
 * 
 * 整合了所有模块的头文件，包含完整的系统定义和接口
 */

#ifndef RECIPE_SYSTEM_H
#define RECIPE_SYSTEM_H

// 包含所有子模块头文件
#include "linked_list.h"
#include "recipe.h"
#include "recipe_manage.h"
#include "recipe_file.h"
#include "recipe_search.h"
#include "recipe_sort.h"
#include "recipe_ui.h"

#endif // RECIPE_SYSTEM_H