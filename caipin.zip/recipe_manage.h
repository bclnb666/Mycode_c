/**
 * @file recipe_manage.h
 * @author 成员B姓名
 * @brief 菜品管理系统接口定义
 * @date 2024-01-15
 */

#ifndef RECIPE_MANAGE_H
#define RECIPE_MANAGE_H

#include "recipe.h"

// 菜品管理器结构
typedef struct RecipeManager {
    List *recipes;          // 菜品链表
    int next_id;            // 下一个可用ID
} RecipeManager;

// ==================== 菜品管理API ====================

/**
 * @brief 创建菜品管理器
 * 
 * @return RecipeManager* 成功返回管理器指针，失败返回NULL
 */
RecipeManager* manager_create();

/**
 * @brief 销毁菜品管理器，释放所有资源
 * 
 * @param manager 菜品管理器指针
 */
void manager_destroy(RecipeManager *manager);

/**
 * @brief 添加菜品
 * 
 * @param manager 菜品管理器指针
 * @param recipe 要添加的菜品指针
 * @return int 成功返回0，失败返回-1
 */
int manager_add_recipe(RecipeManager *manager, Recipe *recipe);

/**
 * @brief 删除菜品
 * 
 * @param manager 菜品管理器指针
 * @param id 菜品ID
 * @return int 成功返回0，失败返回-1
 */
int manager_remove_recipe(RecipeManager *manager, int id);

/**
 * @brief 修改菜品
 * 
 * @param manager 菜品管理器指针
 * @param id 菜品ID
 * @param new_recipe 新的菜品信息
 * @return int 成功返回0，失败返回-1
 */
int manager_modify_recipe(RecipeManager *manager, int id, Recipe *new_recipe);

/**
 * @brief 根据ID查找菜品
 * 
 * @param manager 菜品管理器指针
 * @param id 菜品ID
 * @return Recipe* 找到返回菜品指针，未找到返回NULL
 */
Recipe* manager_find_by_id(RecipeManager *manager, int id);

/**
 * @brief 获取菜品数量
 * 
 * @param manager 菜品管理器指针
 * @return int 菜品数量
 */
int manager_get_count(RecipeManager *manager);

/**
 * @brief 显示所有菜品
 * 
 * @param manager 菜品管理器指针
 */
void manager_display_all(RecipeManager *manager);

/**
 * @brief 清空所有菜品
 * 
 * @param manager 菜品管理器指针
 */
void manager_clear_all(RecipeManager *manager);

#endif // RECIPE_MANAGE_H