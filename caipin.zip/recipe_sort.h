/**
 * @file recipe_sort.h
 * @author 成员D姓名
 * @brief 菜品排序功能
 * @date 2024-01-15
 */

#ifndef RECIPE_SORT_H
#define RECIPE_SORT_H

#include "recipe_manage.h"

// ==================== 排序API ====================

/**
 * @brief 按ID升序排序
 * 
 * @param manager 菜品管理器
 */
void manager_sort_by_id(RecipeManager *manager,int mode);

/**
 * @brief 按名称升序排序
 * 
 * @param manager 菜品管理器
 */
void manager_sort_by_name(RecipeManager *manager,int mode);

/**
 * @brief 按总时间升序排序
 * 
 * @param manager 菜品管理器
 */
void manager_sort_by_total_time(RecipeManager *manager,int mode);

/**
 * @brief 按难度升序排序
 * 
 * @param manager 菜品管理器
 */
void manager_sort_by_difficulty(RecipeManager *manager,int mode);

/**
 * @brief 按分类升序排序，同分类内按名称升序排序
 * 
 * @param manager 菜品管理器
 */
void manager_sort_by_category_then_name(RecipeManager *manager,int mode);



#endif // RECIPE_SORT_H
