/**
 * @file recipe_core.c
 * @author 成员A姓名  
 * @brief 菜品数据结构实现
 */

#include "recipe_system.h"
#include <string.h>

// 配料数据的释放函数（简单字符串）
void free_string(void *str) {
    free(str);  // 字符串是malloc分配的
}

// 配料数据的打印函数
void print_string(void *str) {
    if (str) printf("%s", (char *)str);
}

// 创建新菜品
Recipe* recipe_create(int id, const char *name, const char *category) {
    Recipe *recipe = (Recipe *)malloc(sizeof(Recipe));
    if (!recipe) {
        fprintf(stderr, "内存分配失败: recipe_create\n");
        return NULL;
    }
    
    // 初始化基本信息
    recipe->id = id;
    strncpy(recipe->name, name, MAX_NAME_LEN - 1);
    recipe->name[MAX_NAME_LEN - 1] = '\0';
    
    strncpy(recipe->category, category, MAX_CATEGORY_LEN - 1);
    recipe->category[MAX_CATEGORY_LEN - 1] = '\0';
    
    recipe->estimated_time = 0;
    recipe->difficulty = 3;  // 默认中等难度
    
    // 创建配料链表
    recipe->ingredients = list_create(free_string, 
                                     (int (*)(void *, void *))strcmp,
                                     print_string);
    if (!recipe->ingredients) {
        free(recipe);
        return NULL;
    }
    
    return recipe;
}

// 销毁菜品
void recipe_destroy(void *recipe) {
    if (!recipe) return;
    
    Recipe *r = (Recipe *)recipe;
    
    // 销毁配料链表
    if (r->ingredients) {
        list_destroy(r->ingredients);
    }
    
    free(r);
}

// 菜品比较函数（按ID比较）
int recipe_compare(void *a, void *b) {
    if (!a || !b) return 0;
    
    Recipe *recipe_a = (Recipe *)a;
    Recipe *recipe_b = (Recipe *)b;
    
    return recipe_a->id - recipe_b->id;
}

// 菜品打印函数
void recipe_print(void *recipe) {
    if (!recipe) return;
    
    Recipe *r = (Recipe *)recipe;
    printf("ID:%d %s", r->id, r->name);
}

// 添加配料
int recipe_add_ingredient(Recipe *recipe, const char *ingredient) {
    if (!recipe || !ingredient || !recipe->ingredients) {
        return -1;
    }
    
    if (recipe->ingredients->size >= MAX_INGREDIENTS) {
        fprintf(stderr, "配料数量已达上限(%d)\n", MAX_INGREDIENTS);
        return -1;
    }
    
    // 分配并复制字符串
    char *ingredient_copy = strdup(ingredient);
    if (!ingredient_copy) {
        fprintf(stderr, "内存分配失败: recipe_add_ingredient\n");
        return -1;
    }
    
    return list_append(recipe->ingredients, ingredient_copy);
}

// 设置预计时间
void recipe_set_estimated_time(Recipe *recipe, int minutes) {
    if (recipe && minutes >= 0) {
        recipe->estimated_time = minutes;
    }
}

// 设置难度
int recipe_set_difficulty(Recipe *recipe, int level) {
    if (!recipe || level < 1 || level > 5) {
        return -1;
    }
    
    recipe->difficulty = level;
    return 0;
}

// 显示菜品详情
void recipe_display(Recipe *recipe) {
    if (!recipe) {
        printf("菜品不存在\n");
        return;
    }
    
    printf("========== 菜品详情 ==========\n");
    printf("ID:        %d\n", recipe->id);
    printf("名称:      %s\n", recipe->name);
    printf("分类:      %s\n", recipe->category);
    printf("预计时间:  %d分钟\n", recipe->estimated_time);
    printf("难度:      ");
    for (int i = 0; i < recipe->difficulty; i++) printf("★");
    for (int i = recipe->difficulty; i < 5; i++) printf("☆");
    printf(" (%d/5)\n", recipe->difficulty);
    
    printf("配料(%d种): ", recipe->ingredients->size);
    list_print(recipe->ingredients);
    printf("==============================\n");
}

// 检查是否包含某配料
int recipe_has_ingredient(Recipe *recipe, const char *ingredient) {
    if (!recipe || !ingredient || !recipe->ingredients) {
        return 0;
    }
    
    // 遍历配料链表查找
    ListNode *node = recipe->ingredients->head;
    while (node) {
        if (strcmp((char *)node->data, ingredient) == 0) {
            return 1;
        }
        node = node->next;
    }
    
    return 0;
}
